var msg

msg="<h1> Hello Pradnya </h1>"
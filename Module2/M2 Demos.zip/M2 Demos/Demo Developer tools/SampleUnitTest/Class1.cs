﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
////Add the reference Microsoft.VisualStudio.QualityTools.UnitTestFramework to the project to refer this assembly
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Demo01;


namespace SampleUnitTest
{
    [TestClass]
    public class SampleCalcTest
    {
        public class CalculatorTest
        {
            private Calculator calc = null;

            /*[ClassInitialize ]//called only once before any of the Test methods execute */
            [TestInitialize]// called everytime before executing any Test Method 
            public void SetUp()
            {
                calc = new Calculator();
            }

            [TestMethod]
            public void AddNumbers()
            {
                int actual = calc.AddNumbers(6, 7);
                int expected = 13;
                Assert.AreEqual(expected, actual);
            }

            [TestMethod]
            public void SubtractNumbers()
            {
                int expected = calc.SubtractNumbers(12, 7);
                int actual = 5;
                Assert.AreEqual(expected, actual);
            }
           /* [ClassCleanup] // called only once after all the TestMethods are executed*/
            [TestCleanup]//Called everytime after the execution of each TestMethods
            public void deallocate()
            {
                calc = null;
            }

        }
    }
}
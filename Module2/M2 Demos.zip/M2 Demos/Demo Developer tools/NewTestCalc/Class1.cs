﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using Demo01;
namespace NewTestCalc
{
    [TestFixture]
    public class CalcTest
    {
        [Test]
        public void AddTest()
        {
            Calculator calcObj = new Calculator();
            int actualResult = calcObj.AddNumbers(2, 3);
            int expectedResult = 4;
            Assert.AreEqual(expectedResult, actualResult);

        }

   
        [Test]
        public void SubTest()
        {
            Calculator calcObj = new Calculator();
            int actualResult = calcObj.SubtractNumbers(12, 3);
            int expectedResult = 9;
            Assert.AreEqual(expectedResult, actualResult);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Demo01;
namespace TestCalc
{
    [TestFixture]// to instruct the CLR that the Class is a Test Class
    public class TestClass
    {


        [Test] // to instruct the CLR that the Method  is a Test Method
        public void AddTest()
        {
            Calculator cals = new Calculator();
            int addResult = cals.AddNumbers(2, 4);//6
            Assert.AreEqual(6, addResult);
        
        }

        [Test]
        public void SubTest()
        {
            Calculator cals = new Calculator();
            int subResult = cals.SubtractNumbers(12, 4);//8
            Assert.AreEqual(6, subResult);
        
        }

    }
}

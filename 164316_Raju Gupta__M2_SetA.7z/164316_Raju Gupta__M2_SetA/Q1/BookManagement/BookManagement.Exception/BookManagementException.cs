﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagement.Exception
{
    public class BookManagementException: ApplicationException
    {
        public BookManagementException()
            : base()
        {

        }

        public BookManagementException(string message)
            : base(message)
        {

        }

        public BookManagementException(string message, Exception objEx)
            : base(message, objEx)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManagement.Entities;
using BookManagement.Exception;

namespace BookManagement.DataAccessLayer
{
    public class BookDAL
    {
        public static List<Book> objBookList = new List<Book>();

        public bool AddBookDAL(Book objBook)
        {
            bool bookAdded = false;
            try
            {
                objBookList.Add(objBook);
                bookAdded = true;
            }
            catch (SystemException objEx)
            {
                throw new BookManagementException(objEx.Message);
            }

            return bookAdded;
        }
        public List<Book> GetAllBookDAL()
        {
            return objBookList;
        }
    }
}

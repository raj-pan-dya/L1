﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManagement.Entities;//imp
using BookManagement.Exception;//imp
using BookManagement.DataAccessLayer;//imp

namespace BookManagement.BL
{
    public class BookBL
    {
        private static bool ValidateBook(Book objBook)
        {
            StringBuilder objSB = new StringBuilder();
            bool validBook = true;
            if (objBook.bookId ==string.Empty)
            {
                validBook = false;
                objSB.Append(Environment.NewLine + "Book ID should not be empty");

            }
            if (objBook.bookName == string.Empty)
            {
                validBook = false;
                objSB.Append(Environment.NewLine + "Book Name cant be empty");
            }
            if (objBook.bookId.ToString().Length >5)
            {
                validBook = false;
                objSB.Append(Environment.NewLine + "Book ID should not be greater than 5 digits");
            }
           
            if (validBook == false)
                throw new BookManagementException(objSB.ToString());
            return validBook;
        }
        public static bool AddBook(Book objBook)
        {
            bool bookAdded = false;
            try
            {
                if (ValidateBook(objBook))
                {
                    BookDAL objBookDAL = new BookDAL();//responsible for manipulating collection and maintain the same.
                    objBookDAL.AddBookDAL(objBook);
                }
            }
            catch (BookManagementException objBookManagementExp)
            {
                throw objBookManagementExp;

            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return bookAdded;
        }

        public static Book SearchEmployeeBL(int id)
        {
            Book objBook;
            try
            {
                BookDAL objEmployeeDAL = new BookDAL();
                objBook = objEmployeeDAL.SearchBookDAL(id);

            }
            catch (BookManagementException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }

            return objBook;

        }
        public static bool DeleteBookBL(int bookId)
        {
            bool bookDeleted = false;
            try
            {
                if (bookId > 0)//dont pass to validateBook() as it checks everything so write seperate validation
                {


                    BookDAL objBookDAL = new BookDAL();
                    bookDeleted = objBookDAL.DeleteBookDAL(bookId);
                }
                else
                {
                    throw new BookManagementException("Invalid Book Id.");
                }

            }
            catch (BookManagementException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return bookDeleted;
        }

        public static List<Book> ListAllBookBL()
        {
            List<Book> objBookList = null;
            try
            {
                BookDAL objBookDAL = new BookDAL();
                objBookList = objBookDAL.GetAllBookDAL();
            }
            catch (BookManagementException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objBookList;

        }
        
    }
}

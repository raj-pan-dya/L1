﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagement.Entities
{
    public class Book
    {
        private int _bookId;

        public int BookId
        {
            get
            {
                return _bookId;
            }
            set
            {
                _bookId = value;
            }
        }
        private string _bookName;

        public string BookName
        {
            get
            {
                return _bookName;
            }
            set
            {
                _bookName = value;
            }
        }

        private int _isbnNumber;

        public int IsbnNumber
        {
            get
            {
                return _isbnNumber;
            }
            set
            {
                _isbnNumber = value;
            }
        }

        private int _price;

        public int Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }
        private string _publisher;

        public string Publisher
        {
            get
            {
                return _publisher;
            }
            set
            {
                _publisher = value;
            }
        }
        private int _noOfPages;
        public int NumberOfPages
        {
            get
            {
                return _noOfPages;
            }
            set
            {
                _noOfPages = value;
            }
        }
        private string _language;

        public string Language
        {
            get
            {
                return _language;
            }
            set
            {
                _language = value;
            }
        }
        private int _lot;

        public int Lot
        {
            get
            {
                return _lot;
            }
            set
            {
                _lot = value;
            }
        }
        private string _summary;

        public string Summary
        {
            get
            {
                return _summary;
            }
            set
            {
                _summary = value;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookManagement.Entities;
using BookManagement.Exception;
using BookManagement.BL;
namespace BookManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            char choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your choice:");
                int taskFlag;
                taskFlag = Convert.ToInt32(Console.ReadLine());


                switch (taskFlag)
                {

                    case 1:
                        AddBook();
                        break;

                    case 2:
                        DisplayBooks();
                        break;
                    case 3:
                        DeleteBook();
                        break;

                    default:

                        break;

                }
                Console.WriteLine("Do you want to continue? Press 'y' to continue or 'n' to exit");
                choice = Convert.ToChar(Console.ReadLine());

            } while (choice == 'y');
        }

        static void PrintMenu()
        {

            Console.WriteLine("-----Book Management System-----");
            Console.WriteLine("Press 1 to Add Book");
            Console.WriteLine("Press 2 to display books ");
            Console.WriteLine("Press 2 to display books based on id ");



        }


        static void AddBook()
        {
            try
            {
                Book objBook = new Book();
                //presentation layer
                Console.WriteLine("Enter Book Details:");

                Console.WriteLine("Enter  Book Id");
                objBook.BookId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the Book Name:");
                objBook.BookName = Console.ReadLine();

                Console.WriteLine("Enter the ISBN Number:");
                objBook.IsbnNumber = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the price:");
                objBook.Price = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the publisher:");
                objBook.Publisher = Console.ReadLine();

                Console.WriteLine("Enter the Number of pages:");
                objBook.NumberOfPages = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the Language:");
                objBook.Language = Console.ReadLine();

                Console.WriteLine("Enter the Lot:");
                objBook.Lot = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the Summary:");
                objBook.Summary = Console.ReadLine();

                //now business layer
                bool bookAdded;

                bookAdded = BookBL.AddBookBL(objBook);

                if (bookAdded)
                {
                    Console.WriteLine("Employee added successfully.");
                }
                else
                {
                    Console.WriteLine("Employee couldn't be added.");
                }
            }
            catch (BookManagementException objBookManagementExp)
            {
                Console.WriteLine(objBookManagementExp.Message);//since no one is there to catch exception as it is Presentation Layer.
            }


        }

        static void DeleteBook()
        {
            try
            {
                bool bookDeleted;
                int id;
                //employeeDeleted = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Id: ");
                id = Convert.ToInt32(Console.ReadLine());

                Book objEmployee = BookBL.SearchBookBL(id);

                if (objEmployee != null)
                {
                    bookDeleted = BookBL.DeleteBookBL(id);
                    if (bookDeleted)
                    {
                        Console.WriteLine("Book record deleted successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Book data coludn't be deleted");
                    }
                }
                else
                {
                    Console.WriteLine("Book record couldn't be found.");
                }


            }
            catch (BookManagementException objBookManagementExp)
            {
                Console.WriteLine(objBookManagementExp.Message);
            }

        }

        static void DisplayBooks()
        {
            try
            {
                List<Book> objBookList;//just declare dont initialize
                objBookList = BookBL.GetAllBookBL();
                if (objBookList != null)
                {
                    Console.WriteLine("List of Book Details: ");
                    foreach (Book objBook in objBookList)
                    {
                        Console.WriteLine("ID: {0}, Name:{1}, ISBN Number: {2}, Price: {3},Publisher: {4}, Number of pages:{5}, Language: {6}, Lot: {7}, Summary: {8}", objBook.BookId, objBook.BookName, objBook.IsbnNumber, objBook.Price, objBook.Publisher, objBook.NumberOfPages, objBook.Language, objBook.Lot, objBook.Summary);
                    }
                }
                else
                {
                    Console.WriteLine("No Employee records found.");
                }
            }
            catch BookMangementException objBookManagementExp)
            {
                Console.WriteLine(objBookManagement.Message);
            }
            }

        }
    }
}


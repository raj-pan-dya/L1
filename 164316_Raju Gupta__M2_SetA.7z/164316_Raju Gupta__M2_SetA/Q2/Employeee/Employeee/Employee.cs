﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employeee
{
    class Employee
    {
        private int _employeeid;

        public int EmployeeId
        {
            get
            {
                return _employeeid;
            }
            set
            {
                _employeeid = value;
            }
        }
        private string _employeeName;

        public string EmployeeName
        {
            get
            {
                return _employeeName;
            }
            set
            {
                _employeeName = value;
            }
        }

        private string _gender;

        public string Gender
        {
            get
            {
                return _gender;
            }
            set
            {
                _gender = value;
            }
        }

        private DateTime _dateOfBirth;

        public DateTime DateOfBirth
        {
            get
            {
                return _dateOfBirth;
            }
            set
            {
                _dateOfBirth = value;
            }
        }
    }
}
